package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class CheckoutPage {
    WebDriver driver;

    By addressField = By.id("address");
    By paymentField = By.id("payment");
    By placeOrderButton = By.id("place-order");

    public CheckoutPage(WebDriver driver) {
        this.driver = driver;
    }

    public void checkout(String address, String payment) {
        driver.findElement(addressField).sendKeys(address);
        driver.findElement(paymentField).sendKeys(payment);
        driver.findElement(placeOrderButton).click();
    }

    public boolean verifyOrderSuccess() {
        return driver.getCurrentUrl().contains("order-success");
    }
}