package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class RegisterPage {

    WebDriver driver;

        // LOCATORS
        public By nameField = By.xpath("//input[@data-qa='signup-name']");
        public By emailField = By.xpath("//input[@data-qa='signup-email']");
        public By signupBtn = By.xpath("//button[@data-qa='signup-button']");
        public By enterAccountInfoText = By.xpath("//b[contains(text(),'Enter Account Information')]");

        public RegisterPage(WebDriver driver) {
            this.driver = driver;
        }

        // ACTIONS
        public void enterName(String name) {
            driver.findElement(nameField).sendKeys(name);
        }

        public void enterEmail(String email) {
            driver.findElement(emailField).sendKeys(email);
        }

        public void clickSignup() {
            driver.findElement(signupBtn).click();
        }

        // ASSERT ELEMENT
        public boolean isEnterAccountInfoVisible() {
            return driver.findElement(enterAccountInfoText).isDisplayed();
        }
    }
