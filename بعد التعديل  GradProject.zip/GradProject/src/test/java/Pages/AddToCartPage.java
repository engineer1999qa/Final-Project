package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class AddToCartPage {


    WebDriver driver;

    public AddToCartPage(WebDriver driver){
        this.driver = driver;
    }

    By firstProduct = By.xpath("(//a[contains(text(),'Add to cart')])[1]");
    By continueBtn = By.xpath("//button[contains(text(),'Continue Shopping')]");
    By cartBtn = By.xpath("//a[@href='/view_cart']");
    By cartProduct = By.xpath("//tbody/tr");


    public void openProducts(){
        driver.get("https://automationexercise.com/products");
    }

    public void addFirstProduct(){
        driver.findElement(firstProduct).click();
        driver.findElement(continueBtn).click();
    }

    public void openCart(){
        driver.findElement(cartBtn).click();
    }

    public boolean isProductInCart(){
        return driver.findElement(cartProduct).isDisplayed();
    }

}
