package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class SubscriptionPage {
    WebDriver driver;

    public SubscriptionPage(WebDriver driver){
        this.driver = driver;
    }

    By emailInput = By.id("susbscribe_email");
    By arrowBtn = By.id("subscribe");
    By successMsg = By.xpath("//*[contains(text(),'You have been successfully subscribed')]");

    public void openHome(){
        driver.get("https://automationexercise.com/");
    }

    public void subscribe(String email){
        driver.findElement(emailInput).sendKeys(email);
        driver.findElement(arrowBtn).click();
    }

    public boolean isSubscribed(){
        return driver.findElement(successMsg).isDisplayed();
    }
}

