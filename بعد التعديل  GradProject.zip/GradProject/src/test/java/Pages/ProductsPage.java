package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ProductsPage {

    WebDriver driver;

    public ProductsPage(WebDriver driver){
        this.driver = driver;
    }

    By searchInput = By.id("search_product");
    By searchBtn = By.id("submit_search");
    By productsResult = By.xpath("//div[@class='features_items']");

    public void openProducts(){
        driver.get("https://automationexercise.com/products");
    }

    public void searchProduct(String name){
        driver.findElement(searchInput).sendKeys(name);
        driver.findElement(searchBtn).click();
    }

    public boolean isSearchResultVisible(){
        return driver.findElement(productsResult).isDisplayed();
    }
}
