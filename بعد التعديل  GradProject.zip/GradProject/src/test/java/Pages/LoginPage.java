package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage {

    WebDriver driver;
    // Locators
     By emailField = By.xpath("//input[@data-qa='login-email']");
     By passwordField = By.xpath("//input[@data-qa='login-password']");
     By loginBtn = By.xpath("//button[@data-qa='login-button']");
     By incorrectMsg = By.xpath("//*[contains(text(),'Your email or password is incorrect!')]");

    public LoginPage(WebDriver driver) {
        this.driver = driver;
    }

    public void enterEmail(String email) {
        driver.findElement(emailField).sendKeys(email);
    }

    public void enterPassword(String pass) {
        driver.findElement(passwordField).sendKeys(pass);
    }

    public void clickLogin() {
        driver.findElement(loginBtn).click();
    }

    public boolean isIncorrectMsgVisible() {
        return driver.findElement(incorrectMsg).isDisplayed();
    }
}
