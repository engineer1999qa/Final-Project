package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class CartPage {
    WebDriver driver;

    By cartItems = By.cssSelector(".cart-item");
    By cartQuantity = By.cssSelector(".cart-quantity");

    public CartPage(WebDriver driver) {
        this.driver = driver;
    }

    public int getCartQuantity() {
        String quantity = driver.findElement(cartQuantity).getText();
        return Integer.parseInt(quantity);
    }
}