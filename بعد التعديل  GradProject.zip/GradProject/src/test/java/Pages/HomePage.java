package Pages;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

    public class HomePage {

        WebDriver driver;

        // LOCATORS
        By signupLoginBtn = By.xpath("//a[contains(text(),'Signup / Login')]");
        By logo = By.xpath("//img[@alt='Website for automation practice']");
        By loggedInUser = By.xpath("//a[contains(text(),'Logged in as')]");

        By subscriptionField = By.id("susbscribe_email");
        By subscriptionBtn = By.id("subscribe");
        By successSubscriptionMsg = By.xpath("//div[contains(text(),'You have been successfully subscribed')]");


        public HomePage(WebDriver driver) {
            this.driver = driver;
        }

        // ACTIONS
        public void navigate() {
            driver.get("https://automationexercise.com/");
        }

        public void clickSignupLogin() {
            driver.findElement(signupLoginBtn).click();
        }



        public boolean isUserLoggedIn() {
            return driver.findElement(loggedInUser).isDisplayed();
        }

        public void enterSubscriptionEmail(String email) {
            driver.findElement(subscriptionField).sendKeys(email);
            driver.findElement(subscriptionBtn).click();
        }

        public boolean isSubscriptionSuccess() {
            return driver.findElement(successSubscriptionMsg).isDisplayed();
        }


        // ASSERT ELEMENT
        public boolean isLogoVisible() {
            return driver.findElement(logo).isDisplayed();
        }
    }
