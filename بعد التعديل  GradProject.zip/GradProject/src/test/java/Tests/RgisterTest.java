package Tests;

import Pages.HomePage;
import Pages.RegisterPage;
import jdk.jfr.Description;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class RgisterTest extends BaseTest { @Description("Test Case: Register a new user successfully")
@Test
public void registerNewUser() {

    HomePage home = new HomePage(driver);
    RegisterPage register = new RegisterPage(driver);

    // 1) LOCATE + ACTION → Home Page
    home.navigate();
    home.clickSignupLogin();

    // 2) LOCATE + ACTION → Register Page
    register.enterName("Demiana");
    register.enterEmail("demiana" + System.currentTimeMillis() + "@test.com");
    register.clickSignup();

    // 3) ASSERT
    Assert.assertTrue(register.isEnterAccountInfoVisible(),
            "Enter Account Information page is NOT visible!");
}
}



