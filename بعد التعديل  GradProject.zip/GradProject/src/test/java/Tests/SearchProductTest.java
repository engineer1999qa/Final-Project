package Tests;

import Pages.ProductsPage;
import org.testng.Assert;
import org.testng.annotations.Test;

public class SearchProductTest extends BaseTest {


    @Test
    public void searchProduct() {

        ProductsPage products = new ProductsPage(driver);

        products.openProducts();
        products.searchProduct("dress");

        Assert.assertTrue(products.isSearchResultVisible(), "Search result not visible!");
    }
}



