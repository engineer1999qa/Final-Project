package Tests;

import Pages.HomePage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class HomePageTest {
    WebDriver driver;
    @Test
    public void verifyHomePageVisible() {
      WebDriver driver = new EdgeDriver();



    }
}

