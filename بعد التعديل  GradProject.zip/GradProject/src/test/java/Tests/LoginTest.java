package Tests;

import Pages.HomePage;
import Pages.LoginPage;
import org.testng.Assert;
import org.testng.annotations.Test;

public class LoginTest extends BaseTest{
    @Test
    public void validLoginTest() {

        HomePage home = new HomePage(driver);
        LoginPage login = new LoginPage(driver);

        home.navigate();
        home.clickSignupLogin();

        login.enterEmail("test123@gmail.com");
        login.enterPassword("123456");
        login.clickLogin();

        Assert.assertTrue(home.isUserLoggedIn(), "User not logged in successfully!");
    }

    @Test
    public void invalidLoginTest() {

        HomePage home = new HomePage(driver);
        LoginPage login = new LoginPage(driver);

        home.navigate();
        home.clickSignupLogin();

        login.enterEmail("demiana234@gmail.com");
        login.enterPassword("12345");
        login.clickLogin();

        Assert.assertTrue(login.isIncorrectMsgVisible(), "Incorrect message not shown");
    }
}

