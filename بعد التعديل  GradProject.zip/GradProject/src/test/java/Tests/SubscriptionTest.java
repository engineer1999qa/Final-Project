package Tests;

import Pages.SubscriptionPage;
import org.testng.Assert;
import org.testng.annotations.Test;

public class SubscriptionTest extends BaseTest {

    @Test
    public void verifySubscription() {

        SubscriptionPage s = new SubscriptionPage(driver);

        s.openHome();
        s.subscribe("test@test.com");

        Assert.assertTrue(s.isSubscribed(), "Subscription FAILED!");
    }
}
