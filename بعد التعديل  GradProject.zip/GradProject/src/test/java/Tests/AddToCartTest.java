package Tests;

import Pages.AddToCartPage;
import org.testng.Assert;
import org.testng.annotations.Test;

public class AddToCartTest extends BaseTest {




    @Test
    public void addProductToCart() {

        AddToCartPage cart = new AddToCartPage(driver);

        cart.openProducts();
        cart.addFirstProduct();
        cart.openCart();

        Assert.assertTrue(cart.isProductInCart(), "Product NOT added to cart!");
    }
}



