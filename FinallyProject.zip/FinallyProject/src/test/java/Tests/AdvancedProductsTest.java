package Tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.List;

public class AdvancedProductsTest extends AutomationExersiceTest{

    @Test
    public void viewCategoryProducts() {
        // Women category
        WebElement womenCategory = driver.findElement(By.xpath("//a[text()='Women']"));
        womenCategory.click();
        driver.findElement(By.xpath("(//a[contains(text(),'Dress')])[1]")).click();
        Assert.assertTrue(driver.getPageSource().contains("WOMEN - TOPS PRODUCTS"));

        // Men sub-category
        driver.findElement(By.xpath("(//a[text()='Men'])[1]")).click();
        Assert.assertTrue(driver.getCurrentUrl().contains("category_products"));
    }

    @Test
    public void viewAndCartBrandProducts() {
        driver.findElement(By.linkText("Products")).click();
        List<WebElement> brands = driver.findElements(By.cssSelector(".brands_products li a"));
        Assert.assertTrue(brands.size() > 0);

        brands.get(0).click();
        Assert.assertTrue(driver.getCurrentUrl().contains("brand_products"));
        brands.get(1).click();
        Assert.assertTrue(driver.getCurrentUrl().contains("brand_products"));
    }

    @Test
    public void searchProductsVerifyCartAfterLogin() {
        Actions actions = new Actions(driver);
        driver.findElement(By.linkText("Products")).click();
        driver.findElement(By.id("search_product")).sendKeys("Dress");
        driver.findElement(By.id("submit_search")).click();

        List<WebElement> products = driver.findElements(By.xpath("//a[text()='Add to cart']"));
        for(WebElement p : products) {
            actions.moveToElement(p).click().perform();
        }

        driver.findElement(By.linkText("Cart")).click();
        Assert.assertTrue(driver.findElements(By.cssSelector(".cart_info")).size() > 0);

        // Login
        driver.findElement(By.linkText("Signup / Login")).click();
        driver.findElement(By.xpath("//input[@data-qa='login-email']")).sendKeys("checkoutuser@example.com");
        driver.findElement(By.xpath("//input[@data-qa='login-password']")).sendKeys("123456");
        driver.findElement(By.xpath("//button[@data-qa='login-button']")).click();

        driver.findElement(By.linkText("Cart")).click();
        Assert.assertTrue(driver.findElements(By.cssSelector(".cart_info")).size() > 0);
    }

    @Test
    public void addToCartFromRecommendedItems() {
        Actions actions = new Actions(driver);
        WebElement recommended = driver.findElement(By.xpath("//h2[text()='Recommended Items']"));
        actions.moveToElement(recommended).perform();
        driver.findElement(By.xpath("//a[text()='Add To Cart']")).click();
        driver.findElement(By.xpath("//a[text()='View Cart']")).click();

        Assert.assertTrue(driver.findElements(By.cssSelector(".cart_info")).size() > 0);
    }
}