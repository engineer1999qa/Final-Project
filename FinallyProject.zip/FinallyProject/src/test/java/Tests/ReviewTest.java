package Tests;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

public class ReviewTest extends AutomationExersiceTest {

    @Test
    public void addReviewOnProduct() {
        driver.findElement(By.linkText("Products")).click();
        driver.findElement(By.xpath("(//a[text()='View Product'])[1]")).click();

        Assert.assertTrue(driver.findElement(By.xpath("//h2[text()='Write Your Review']")).isDisplayed());
        driver.findElement(By.id("name")).sendKeys("Test User");
        driver.findElement(By.id("email")).sendKeys("testuser@example.com");
        driver.findElement(By.id("review")).sendKeys("This is a test review.");
        driver.findElement(By.id("button-review")).click();

        Assert.assertTrue(driver.getPageSource().contains("Thank you for your review."));
    }
}