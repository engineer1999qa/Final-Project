package Tests;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TestCasesPageTest extends AutomationExersiceTest {

    @Test
    public void verifyTestCasesPage() {
        driver.findElement(By.linkText("Test Cases")).click();
        Assert.assertTrue(driver.getCurrentUrl().contains("test_cases"));
    }
}