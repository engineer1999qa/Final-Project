package Tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

public class CheckoutTest extends AutomationExersiceTest {

    @Test
    public void placeOrderRegisterWhileCheckout() {
        // Add product to cart
        driver.findElement(By.linkText("Products")).click();
        driver.findElement(By.xpath("(//a[text()='Add to cart'])[1]")).click();
        driver.findElement(By.xpath("//a[text()='View Cart']")).click();
        driver.findElement(By.xpath("//a[text()='Proceed To Checkout']")).click();

        // Register
        driver.findElement(By.linkText("Register / Login")).click();
        driver.findElement(By.name("name")).sendKeys("TestUser");
        driver.findElement(By.xpath("//input[@data-qa='signup-email']")).sendKeys("checkoutuser@example.com");
        driver.findElement(By.xpath("//button[text()='Signup']")).click();

        driver.findElement(By.id("id_gender1")).click();
        driver.findElement(By.id("password")).sendKeys("123456");
        driver.findElement(By.id("first_name")).sendKeys("Test");
        driver.findElement(By.id("last_name")).sendKeys("User");
        driver.findElement(By.id("address1")).sendKeys("123 Street");
        driver.findElement(By.id("country")).sendKeys("United States");
        driver.findElement(By.id("state")).sendKeys("CA");
        driver.findElement(By.id("city")).sendKeys("Los Angeles");
        driver.findElement(By.id("zipcode")).sendKeys("90001");
        driver.findElement(By.id("mobile_number")).sendKeys("1234567890");
        driver.findElement(By.xpath("//button[text()='Create Account']")).click();

        Assert.assertTrue(driver.findElement(By.xpath("//b[text()='Account Created!']")).isDisplayed());
        driver.findElement(By.linkText("Continue")).click();

        // Checkout
        driver.findElement(By.linkText("Cart")).click();
        driver.findElement(By.xpath("//a[text()='Proceed To Checkout']")).click();
        WebElement comment = driver.findElement(By.name("message"));
        comment.sendKeys("This is a test order.");
        driver.findElement(By.linkText("Place Order")).click();

        // Payment
        driver.findElement(By.name("name_on_card")).sendKeys("Test User");
        driver.findElement(By.name("card_number")).sendKeys("4111111111111111");
        driver.findElement(By.name("cvc")).sendKeys("123");
        driver.findElement(By.name("expiry_month")).sendKeys("12");
        driver.findElement(By.name("expiry_year")).sendKeys("2025");
        driver.findElement(By.id("submit")).click();

        Assert.assertTrue(driver.getPageSource().contains("Your order has been placed successfully!"));

        // Delete Account
        driver.findElement(By.linkText("Delete Account")).click();
        Assert.assertTrue(driver.getPageSource().contains("Account Deleted!"));
        driver.findElement(By.linkText("Continue")).click();
    }
}