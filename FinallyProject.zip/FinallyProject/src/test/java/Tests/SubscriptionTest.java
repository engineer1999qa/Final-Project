package tests;

import Tests.AutomationExersiceTest;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.testng.Assert;
import org.testng.annotations.Test;

public class SubscriptionTest extends AutomationExersiceTest {

    @Test
    public void subscriptionHomePage() {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollTo(0, document.body.scrollHeight);");

        Assert.assertTrue(driver.findElement(By.xpath("//h2[text()='Subscription']")).isDisplayed());
        driver.findElement(By.id("susbscribe_email")).sendKeys("subscribe@example.com");
        driver.findElement(By.id("subscribe")).click();

        Assert.assertTrue(driver.findElement(By.xpath("//div[contains(text(),'You have been successfully subscribed!')]")).isDisplayed());
    }

    @Test
    public void subscriptionCartPage() {
        driver.findElement(By.linkText("Cart")).click();
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollTo(0, document.body.scrollHeight);");

        Assert.assertTrue(driver.findElement(By.xpath("//h2[text()='Subscription']")).isDisplayed());
        driver.findElement(By.id("susbscribe_email")).sendKeys("subscribecart@example.com");
        driver.findElement(By.id("subscribe")).click();
        Assert.assertTrue(driver.findElement(By.xpath("//div[contains(text(),'You have been successfully subscribed!')]")).isDisplayed());
    }

    @Test
    public void scrollUpUsingArrow() {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollTo(0, document.body.scrollHeight);");
        driver.findElement(By.id("scrollUp")).click();

        Assert.assertTrue(driver.getPageSource().contains("Full-Fledged practice website for Automation Engineers"));
    }

    @Test
    public void scrollUpWithoutArrow() {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollTo(0, document.body.scrollHeight);");
        js.executeScript("window.scrollTo(0, 0);");

        Assert.assertTrue(driver.getPageSource().contains("Full-Fledged practice website for Automation Engineers"));
    }
}