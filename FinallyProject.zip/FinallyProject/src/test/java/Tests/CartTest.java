package Tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.List;

public class CartTest extends AutomationExersiceTest {

    @Test
    public void addMultipleProductsToCart() {
        Actions actions = new Actions(driver);
        driver.findElement(By.linkText("Products")).click();

        WebElement firstProduct = driver.findElement(By.xpath("(//div[@class='product-image-wrapper'])[1]"));
        actions.moveToElement(firstProduct).perform();
        firstProduct.findElement(By.xpath(".//a[text()='Add to cart']")).click();
        driver.findElement(By.xpath("//button[text()='Continue Shopping']")).click();

        WebElement secondProduct = driver.findElement(By.xpath("(//div[@class='product-image-wrapper'])[2]"));
        actions.moveToElement(secondProduct).perform();
        secondProduct.findElement(By.xpath(".//a[text()='Add to cart']")).click();
        driver.findElement(By.xpath("//a[text()='View Cart']")).click();

        List<WebElement> cartItems = driver.findElements(By.cssSelector(".cart_info"));
        Assert.assertTrue(cartItems.size() >= 2);
    }

    @Test
    public void verifyProductQuantity() {
        driver.findElement(By.xpath("(//a[text()='View Product'])[1]")).click();
        WebElement qty = driver.findElement(By.id("quantity"));
        qty.clear();
        qty.sendKeys("4");
        driver.findElement(By.xpath("//button[text()='Add to cart']")).click();
        driver.findElement(By.xpath("//a[text()='View Cart']")).click();

        String quantity = driver.findElement(By.cssSelector(".cart_quantity input")).getAttribute("value");
        Assert.assertEquals(quantity, "4");
    }

    @Test
    public void removeProductFromCart() {
        driver.findElement(By.linkText("Products")).click();
        driver.findElement(By.xpath("(//a[text()='Add to cart'])[1]")).click();
        driver.findElement(By.xpath("//a[text()='View Cart']")).click();

        driver.findElement(By.cssSelector(".cart_quantity_delete")).click();
        Assert.assertTrue(driver.getPageSource().contains("Your shopping cart is empty!"));
    }
}