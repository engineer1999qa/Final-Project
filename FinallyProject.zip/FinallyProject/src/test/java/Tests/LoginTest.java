package Tests;

import Tests.AutomationExersiceTest;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

public class LoginTest extends AutomationExersiceTest {

    @Test
    public void loginWithCorrectDetails() {
        driver.findElement(By.linkText("Signup / Login")).click();
        Assert.assertTrue(driver.findElement(By.xpath("//h2[text()='Login to your account']")).isDisplayed());

        driver.findElement(By.xpath("//input[@data-qa='login-email']")).sendKeys("testuser1234@example.com");
        driver.findElement(By.xpath("//input[@data-qa='login-password']")).sendKeys("123456");
        driver.findElement(By.xpath("//button[@data-qa='login-button']")).click();

        Assert.assertTrue(driver.findElement(By.xpath("//a[contains(text(),'Logged in as')]")).isDisplayed());
        driver.findElement(By.linkText("Delete Account")).click();
        Assert.assertTrue(driver.findElement(By.xpath("//b[text()='Account Deleted!']")).isDisplayed());
        driver.findElement(By.linkText("Continue")).click();
    }

    @Test
    public void loginWithIncorrectDetails() {
        driver.findElement(By.linkText("Signup / Login")).click();
        driver.findElement(By.xpath("//input[@data-qa='login-email']")).sendKeys("wrong@example.com");
        driver.findElement(By.xpath("//input[@data-qa='login-password']")).sendKeys("wrongpass");
        driver.findElement(By.xpath("//button[@data-qa='login-button']")).click();

        Assert.assertTrue(driver.findElement(By.xpath("//p[text()='Your email or password is incorrect!']")).isDisplayed());
    }

    @Test
    public void logoutUser() {
        driver.findElement(By.linkText("Signup / Login")).click();
        driver.findElement(By.xpath("//input[@data-qa='login-email']")).sendKeys("testuser1234@example.com");
        driver.findElement(By.xpath("//input[@data-qa='login-password']")).sendKeys("123456");
        driver.findElement(By.xpath("//button[@data-qa='login-button']")).click();

        Assert.assertTrue(driver.findElement(By.xpath("//a[contains(text(),'Logged in as')]")).isDisplayed());
        driver.findElement(By.linkText("Logout")).click();
        Assert.assertTrue(driver.findElement(By.xpath("//h2[text()='Login to your account']")).isDisplayed());
    }
}