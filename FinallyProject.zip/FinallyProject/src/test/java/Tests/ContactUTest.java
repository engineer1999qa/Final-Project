package Tests;

import Tests.AutomationExersiceTest;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

public class ContactUTest extends AutomationExersiceTest {

    @Test
    public void contactUsForm() throws InterruptedException {
        driver.findElement(By.linkText("Contact Us")).click();
        Assert.assertTrue(driver.findElement(By.xpath("//h2[text()='Get In Touch']")).isDisplayed());

        driver.findElement(By.name("name")).sendKeys("Test User");
        driver.findElement(By.name("email")).sendKeys("testuser@example.com");
        driver.findElement(By.name("subject")).sendKeys("Test Subject");
        driver.findElement(By.name("message")).sendKeys("This is a test message.");

        driver.findElement(By.name("upload_file")).sendKeys("C:\\path\\to\\file.txt");
        driver.findElement(By.name("submit")).click();

        driver.switchTo().alert().accept();
        Assert.assertTrue(driver.findElement(By.xpath("//div[contains(text(),'Success! Your details have been submitted successfully.')]")).isDisplayed());

        driver.findElement(By.linkText("Home")).click();
        Assert.assertTrue(driver.getTitle().contains("Automation Exercise"));
    }
}