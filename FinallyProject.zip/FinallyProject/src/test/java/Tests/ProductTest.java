package Tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.Test;
import java.util.List;

public class ProductTest extends AutomationExersiceTest{

    @Test
    public void allProductsDetail() {
        driver.findElement(By.linkText("Products")).click();
        Assert.assertTrue(driver.getCurrentUrl().contains("products"));

        List<WebElement> products = driver.findElements(By.cssSelector(".productinfo.text-center"));
        Assert.assertTrue(products.size() > 0);

        driver.findElement(By.xpath("(//a[text()='View Product'])[1]")).click();
        Assert.assertTrue(driver.findElement(By.xpath("//div[@class='product-information']")).isDisplayed());
    }

    @Test
    public void searchProduct() {
        driver.findElement(By.linkText("Products")).click();
        driver.findElement(By.id("search_product")).sendKeys("Dress");
        driver.findElement(By.id("submit_search")).click();

        Assert.assertTrue(driver.findElement(By.xpath("//h2[text()='Searched Products']")).isDisplayed());
        List<WebElement> searchResults = driver.findElements(By.cssSelector(".productinfo.text-center"));
        Assert.assertTrue(searchResults.size() > 0);
    }

    @Test
    public void addProductsToCart() {
        Actions actions = new Actions(driver);
        driver.findElement(By.linkText("Products")).click();

        WebElement firstProduct = driver.findElement(By.xpath("(//div[@class='product-image-wrapper'])[1]"));
        actions.moveToElement(firstProduct).perform();
        firstProduct.findElement(By.xpath(".//a[text()='Add to cart']")).click();
        driver.findElement(By.xpath("//button[text()='Continue Shopping']")).click();

        WebElement secondProduct = driver.findElement(By.xpath("(//div[@class='product-image-wrapper'])[2]"));
        actions.moveToElement(secondProduct).perform();
        secondProduct.findElement(By.xpath(".//a[text()='Add to cart']")).click();
        driver.findElement(By.xpath("//a[text()='View Cart']")).click();

        List<WebElement> cartItems = driver.findElements(By.cssSelector(".cart_info"));
        Assert.assertTrue(cartItems.size() >= 2);
    }
}